#include <iostream>
#include <string>
#include <vector>

//integrantes: jose luis maraboli , benjamin concha
using namespace std;


class Pregunta {
public:
  string tipo;
  string enunciado;
  string nivelTaxonomico;
  string respuestaCorrecta;

  Pregunta() {}

  Pregunta(string tipo, string enunciado, string nivelTaxonomico, string respuestaCorrecta)
      : tipo(tipo), enunciado(enunciado), nivelTaxonomico(nivelTaxonomico), respuestaCorrecta(respuestaCorrecta) {}
};


class Evaluacion {
public:
  string asignatura;
  int tiempomaximo;
  int cantidadpreguntas;
  vector<Pregunta> preguntas;

  Evaluacion(string asignatura, int tiempomaximo, int cantidadpreguntas)
      : asignatura(asignatura), tiempomaximo(tiempomaximo),
        cantidadpreguntas(cantidadpreguntas) {}
};

class SistemaEvaluaciones {
private:
  vector<Evaluacion> evaluaciones;

public:
  void crear();
  void borrar();
  void consultar();
  void buscar();
  void actualizar();
};

void SistemaEvaluaciones::crear() {
  string asignatura;
  int tiempomaximo, cantidadpreguntas;

  cout << "\n---Crear nueva evaluación---\n";
  cout << "Ingrese la asignatura de la evaluación: ";
  getline(cin, asignatura);

  cout << "Ingrese el tiempo de duración de la evaluacion (en minutos): ";
  cin >> tiempomaximo;

  cout << "Ingrese la cantidad de preguntas: ";
  cin >> cantidadpreguntas;
  cin.ignore();

  Evaluacion nuevaEvaluacion(asignatura, tiempomaximo, cantidadpreguntas);

  for (int i = 0; i < cantidadpreguntas; i++) {
    int tipoOpcion;
    string tipo, enunciado, nivel, respuestaCorrecta;
    int nivelOpcion;

    cout << "\nPregunta " << i + 1 << ":\n";
    cout << "Tipo:\n1. Verdadero o Falso\n2. Opción Múltiple\nSeleccione: ";
    cin >> tipoOpcion;
    cin.ignore();

    switch (tipoOpcion) {
    case 1:
      tipo = "Verdadero o Falso";
      break;
    case 2:
      tipo = "Opción Múltiple";
      break;
    default:
      cout << "Opción inválida. Se asignará 'Opción Múltiple' por defecto.\n";
      tipo = "Opción Múltiple";
    }

    cout << "Ingrese el enunciado de la pregunta: ";
    getline(cin, enunciado);

    cout << "Seleccione el nivel taxonómico de la pregunta:\n";
    cout << "1. Recordar\n2. Comprender\n3. Aplicar\n4. Analizar\n5. Evaluar\n6. Crear\nSeleccione: ";
    cin >> nivelOpcion;
    cin.ignore();

    switch (nivelOpcion) {
    case 1: nivel = "Recordar"; break;
    case 2: nivel = "Comprender"; break;
    case 3: nivel = "Aplicar"; break;
    case 4: nivel = "Analizar"; break;
    case 5: nivel = "Evaluar"; break;
    case 6: nivel = "Crear"; break;
    default:
      cout << "Opción inválida. Se asignará 'Recordar' por defecto.\n";
      nivel = "Recordar";
    }

    cout << "Ingrese la alternativa o respuesta correcta: ";
    getline(cin, respuestaCorrecta);

    nuevaEvaluacion.preguntas.push_back(Pregunta(tipo, enunciado, nivel, respuestaCorrecta));
  }

  evaluaciones.push_back(nuevaEvaluacion);

  cout << "\n-- Evaluación creada exitosamente --\n";
  cout << "Asignatura: " << nuevaEvaluacion.asignatura << endl;
  cout << "Tiempo máximo: " << nuevaEvaluacion.tiempomaximo << " minutos\n";
  cout << "Cantidad de preguntas: " << nuevaEvaluacion.cantidadpreguntas << endl;

  for (size_t i = 0; i < nuevaEvaluacion.preguntas.size(); i++) {
    cout << i + 1 << ". [" << nuevaEvaluacion.preguntas[i].tipo
         << "]-[" << nuevaEvaluacion.preguntas[i].nivelTaxonomico
         << "]: " << nuevaEvaluacion.preguntas[i].enunciado
         << " (Respuesta correcta: " << nuevaEvaluacion.preguntas[i].respuestaCorrecta << ")\n";
  }
}

void SistemaEvaluaciones::borrar() {
  string asignatura;
  cout << "Ingrese la asignatura de la evaluación a borrar: ";
  getline(cin, asignatura);

  for (auto it = evaluaciones.begin(); it != evaluaciones.end(); ++it) {
    if (it->asignatura == asignatura) {
      evaluaciones.erase(it);
      cout << "Evaluación eliminada exitosamente.\n";
      return;
    }
  }
  cout << "Evaluación no encontrada.\n";
}

void SistemaEvaluaciones::consultar() {
  if (evaluaciones.empty()) {
    cout << "No hay evaluaciones registradas.\n";
    return;
  }

  cout << "--- Lista de evaluaciones ---:\n";
  for (const auto &e : evaluaciones) {
    cout << "- Asignatura: " << e.asignatura << ", Tiempo: " << e.tiempomaximo
         << " minutos, Preguntas: " << e.cantidadpreguntas << endl;
  }
}

void SistemaEvaluaciones::buscar() {
  string asignatura;
  cout << "Ingrese la asignatura de la evaluación a buscar: ";
  getline(cin, asignatura);

  for (const auto &e : evaluaciones) {
    if (e.asignatura == asignatura) {
      cout << "---Evaluación encontrada---\n";
      cout << "[Asignatura: " << e.asignatura << ", Tiempo: " << e.tiempomaximo
           << " minutos, Preguntas: " << e.cantidadpreguntas << "]." << endl;

      for (size_t i = 0; i < e.preguntas.size(); i++) {
        cout << "   " << i + 1 << ". [" << e.preguntas[i].tipo << "]-["
             << e.preguntas[i].nivelTaxonomico << "] "
             << e.preguntas[i].enunciado
             << " (Respuesta correcta: " << e.preguntas[i].respuestaCorrecta << ")\n";
      }
      return;
    }
  }
  cout << "Evaluación no encontrada.\n";
}

void SistemaEvaluaciones::actualizar() {
  string asignatura;
  cout << "Ingrese la asignatura de la evaluación a actualizar: ";
  getline(cin, asignatura);

  for (auto &e : evaluaciones) {
    if (e.asignatura == asignatura) {
      cout << "--Actualizando evaluación--\n";
      cout << "Ingrese la nueva asignatura: ";
      getline(cin, e.asignatura);
      cout << "Ingrese el nuevo tiempo de duración (en minutos): ";
      cin >> e.tiempomaximo;
      cout << "Ingrese la nueva cantidad de preguntas: ";
      cin >> e.cantidadpreguntas;
      cin.ignore();
      cout << "Evaluación actualizada (nota: las preguntas no fueron modificadas).\n";
      return;
    }
  }
  cout << "---Evaluación no encontrada---.\n";
}

int main() {
  SistemaEvaluaciones sistema;
  int opcion;
  bool repetir = true;

  do {
    cout << "\n--- Menu de Evaluaciones ---\n";
    cout << "1. Crear Evaluación\n";
    cout << "2. Borrar Evaluación\n";
    cout << "3. Consultar Evaluaciones\n";
    cout << "4. Buscar Evaluación\n";
    cout << "5. Actualizar Evaluación\n";
    cout << "6. Salir del Programa\n";
    cout << "Seleccione una opción: ";
    cin >> opcion;
    cin.ignore();

    if (cin.fail()) {
      cin.clear();
      cin.ignore(10000, '\n');
      cout << "Por favor, ingrese un número válido.\n";
      continue;
    }

    switch (opcion) {
    case 1:
      sistema.crear();
      break;
    case 2:
      sistema.borrar();
      break;
    case 3:
      sistema.consultar();
      break;
    case 4:
      sistema.buscar();
      break;
    case 5:
      sistema.actualizar();
      break;
    case 6:
      repetir = false;
      cout << "Saliendo del sistema...\n";
      break;
    default:
      cout << "Opción inválida. Intente nuevamente.\n";
      break;
    }
  } while (repetir);

  return 0;
}